package com.hmhs.btpriority

import android.app.*
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Keeps a target Bluetooth speaker "yours". Strategy:
 *  1. Get a proxy to the A2DP profile (audio) via BluetoothAdapter.getProfileProxy.
 *  2. Listen for ACL connect/disconnect broadcasts for the target device.
 *  3. The instant the device is free (disconnected from anyone, or discoverable
 *     as bonded-but-not-connected), immediately call the hidden connect(device)
 *     method via reflection. This wins the race against other phones that rely
 *     on the user manually tapping the device in their Bluetooth menu.
 *  4. Also polls periodically as a safety net, since some OEMs suppress the
 *     ACL broadcasts for already-bonded devices.
 *
 * NOTE: BluetoothA2dp.connect()/disconnect() are @hide APIs. On most AOSP-based
 * builds a third-party app CAN call them via reflection. Some OEM skins
 * (notably some Samsung/MIUI builds on newer Android versions) block this for
 * non-privileged apps and the reflection call will silently no-op or throw.
 * If that happens on your phone, the fallback below opens the system Bluetooth
 * settings screen instead so you can tap it manually as fast as possible.
 */
class BluetoothReconnectService : Service() {

    private lateinit var adapter: BluetoothAdapter
    private var a2dpProxy: BluetoothA2dp? = null
    private var targetAddress: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pollingActive = true

    companion object {
        const val CHANNEL_ID = "bt_priority_channel"
        const val NOTIF_ID = 1
        const val EXTRA_DEVICE_ADDRESS = "device_address"
        private const val TAG = "BTPriority"
        private const val POLL_INTERVAL_MS = 4000L
    }

    private val aclReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                ?: return
            if (device.address != targetAddress) return

            when (intent.action) {
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    Log.d(TAG, "Target disconnected from someone (or us). Racing to reconnect.")
                    attemptConnect(device)
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    Log.d(TAG, "Target is now connected (hopefully to us).")
                    updateNotification("Connected to priority speaker")
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val address = intent?.getStringExtra(EXTRA_DEVICE_ADDRESS)
        if (address != null) targetAddress = address

        startForeground(NOTIF_ID, buildNotification("Watching for priority speaker…"))

        registerReceiver(aclReceiver, IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        })

        adapter.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dpProxy = proxy as BluetoothA2dp
                    startPolling()
                }
            }
            override fun onServiceDisconnected(profile: Int) {
                a2dpProxy = null
            }
        }, BluetoothProfile.A2DP)

        return START_STICKY
    }

    private fun startPolling() {
        pollingActive = true
        handler.post(object : Runnable {
            override fun run() {
                if (!pollingActive) return
                checkAndReclaim()
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        })
    }

    private fun checkAndReclaim() {
        val proxy = a2dpProxy ?: return
        val address = targetAddress ?: return
        val device = adapter.bondedDevices.firstOrNull { it.address == address } ?: return

        val connectedDevices = try { proxy.connectedDevices } catch (e: SecurityException) { emptyList() }
        val isConnected = connectedDevices.any { it.address == address }

        if (!isConnected) {
            Log.d(TAG, "Priority speaker not connected to us. Attempting reclaim.")
            attemptConnect(device)
        }
    }

    /** Calls the hidden BluetoothA2dp.connect(device) via reflection. */
    private fun attemptConnect(device: BluetoothDevice) {
        val proxy = a2dpProxy ?: return
        try {
            val method = proxy.javaClass.getMethod("connect", BluetoothDevice::class.java)
            val result = method.invoke(proxy, device) as? Boolean ?: false
            if (result) {
                updateNotification("Reclaiming priority speaker…")
            } else {
                fallbackToSystemSettings()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Reflection connect() failed, falling back to system settings: ${e.message}")
            fallbackToSystemSettings()
        }
    }

    private fun fallbackToSystemSettings() {
        updateNotification("Couldn't auto-connect — tap to open Bluetooth settings")
    }

    private fun buildNotification(text: String): Notification {
        val openSettingsIntent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)
        val pi = PendingIntent.getActivity(
            this, 0, openSettingsIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BT Priority active")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "BT Priority", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        pollingActive = false
        try { unregisterReceiver(aclReceiver) } catch (e: Exception) {}
        a2dpProxy?.let { adapter.closeProfileProxy(BluetoothProfile.A2DP, it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
