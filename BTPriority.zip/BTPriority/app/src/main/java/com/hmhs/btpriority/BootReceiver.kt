package com.hmhs.btpriority

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences("bt_priority_prefs", Context.MODE_PRIVATE)
        val address = prefs.getString("priority_address", null) ?: return

        val serviceIntent = Intent(context, BluetoothReconnectService::class.java)
            .putExtra(BluetoothReconnectService.EXTRA_DEVICE_ADDRESS, address)
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
