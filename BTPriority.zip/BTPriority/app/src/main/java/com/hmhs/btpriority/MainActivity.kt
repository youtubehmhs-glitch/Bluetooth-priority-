package com.hmhs.btpriority

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.hmhs.btpriority.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: BluetoothAdapter
    private lateinit var prefs: SharedPreferences
    private lateinit var deviceAdapter: DeviceAdapter

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            loadPairedDevices()
        } else {
            binding.statusText.text = "Bluetooth permissions are required to pick a speaker."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("bt_priority_prefs", Context.MODE_PRIVATE)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

        deviceAdapter = DeviceAdapter(emptyList()) { device -> onDeviceChosen(device) }
        binding.deviceList.layoutManager = LinearLayoutManager(this)
        binding.deviceList.adapter = deviceAdapter

        binding.stopButton.setOnClickListener {
            stopService(Intent(this, BluetoothReconnectService::class.java))
            prefs.edit().remove("priority_address").apply()
            binding.statusText.text = "Priority watching stopped."
            deviceAdapter.setSelected(null)
        }

        requestPermissionsIfNeeded()

        prefs.getString("priority_address", null)?.let {
            binding.statusText.text = "Currently prioritizing: ${prefs.getString("priority_name", it)}"
        }
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
            needed += Manifest.permission.BLUETOOTH_SCAN
        } else {
            needed += Manifest.permission.ACCESS_FINE_LOCATION
        }
        needed += Manifest.permission.POST_NOTIFICATIONS

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            loadPairedDevices()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    @Suppress("MissingPermission")
    private fun loadPairedDevices() {
        val bonded = adapter.bondedDevices?.toList() ?: emptyList()
        // Filter to devices that support audio (A2DP) — Bluetooth Class of Device check
        val speakers = bonded.filter { device ->
            val cls = device.bluetoothClass?.deviceClass ?: -1
            cls == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET ||
            cls == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE ||
            cls == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER ||
            cls == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO ||
            cls == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO ||
            cls == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO
        }
        val list = if (speakers.isNotEmpty()) speakers else bonded
        deviceAdapter.updateData(list)

        val savedAddress = prefs.getString("priority_address", null)
        if (savedAddress != null) {
            deviceAdapter.setSelected(savedAddress)
        }

        binding.statusText.text = if (list.isEmpty())
            "No paired devices found. Pair your speaker in system Bluetooth settings first."
        else
            "Tap a device to make it your priority speaker."
    }

    @Suppress("MissingPermission")
    private fun onDeviceChosen(device: BluetoothDevice) {
        prefs.edit()
            .putString("priority_address", device.address)
            .putString("priority_name", device.name ?: device.address)
            .apply()

        val intent = Intent(this, BluetoothReconnectService::class.java)
            .putExtra(BluetoothReconnectService.EXTRA_DEVICE_ADDRESS, device.address)
        ContextCompat.startForegroundService(this, intent)

        deviceAdapter.setSelected(device.address)
        binding.statusText.text = "Prioritizing: ${device.name ?: device.address}\n" +
            "This app will now try to reclaim the connection to this speaker the instant it's free."
    }
}
