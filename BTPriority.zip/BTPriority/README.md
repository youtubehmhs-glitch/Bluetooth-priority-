# BT Priority

Android app (Kotlin) that lets you pick a paired Bluetooth speaker as your
"priority" device. Once picked, a foreground service watches that speaker and
tries to reclaim the connection the instant it becomes free — so you win the
race against other phones instead of them beating you to it.

## Easiest way to get the APK — cloud build, phone only, no computer needed
This project includes a GitHub Actions workflow that builds the APK automatically.

1. On your phone, create a free account at github.com (or use the GitHub mobile app).
2. Create a new **public** repository, e.g. `BTPriority`.
3. Use GitHub's "Add file > Upload files" (works from a phone browser) to upload
   everything in this zip — keep the folder structure intact.
4. Go to the **Actions** tab of your repo. A workflow called "Build APK" will
   run automatically (or tap "Run workflow" if it didn't start).
5. Wait ~2–3 minutes for it to finish (green checkmark).
6. Open that workflow run, scroll to **Artifacts**, and download
   `BTPriority-debug-apk` — that's a zip containing `app-debug.apk`.
7. Open the downloaded apk on your phone (Android will ask to allow installs
   from this source once) and install it.

## How to build

1. Install [Android Studio](https://developer.android.com/studio).
2. `File > Open` this folder (the one containing `settings.gradle`).
3. Let Gradle sync (it will download dependencies — needs internet).
4. Plug in your Android phone (USB debugging on) or use an emulator with a
   paired Bluetooth device, and hit **Run**.

## How to use
1. Pair your speaker normally first, in Android's system Bluetooth settings.
2. Open BT Priority, grant the Bluetooth/notification permissions.
3. Tap your speaker in the list — it's now your priority device.
4. Leave the app running in the background (it runs a persistent foreground
   notification, "BT Priority active"). Whenever the speaker disconnects
   from anyone (including you), the app immediately tries to reconnect it to
   your phone.

## Important limitations (please read)
- **This is not a magic "always mine" switch.** `BluetoothA2dp.connect()` is
  a hidden system API. Third-party apps reach it only via reflection. It
  works on a lot of AOSP-based/stock Android phones. On some OEM builds
  (certain Samsung/Xiaomi versions especially on Android 13+) it's blocked
  for non-privileged apps and will silently fail — the notification will
  say "Couldn't auto-connect" and you'll need to tap the speaker manually
  in system settings. There's no reliable, publicly-documented way around
  this without root or being a system app.
- **No app can forcibly disconnect someone else's phone.** "Priority" here
  means "reconnect faster than the other phone," not "kick them off."
- **Multipoint** (two phones connected simultaneously) is a speaker
  hardware/firmware feature — an app can't add it to a speaker that doesn't
  support it.
- Test on your actual phone model early — if reflection is blocked, tell me
  and I'll adjust the fallback behavior (e.g. auto-opening the system
  Bluetooth picker instead of just notifying).

## Project structure
```
app/src/main/java/com/hmhs/btpriority/
  MainActivity.kt              — pick your priority speaker
  BluetoothReconnectService.kt — foreground service, does the reconnect racing
  DeviceAdapter.kt             — paired device list UI
  BootReceiver.kt              — resumes watching after phone reboot
```
